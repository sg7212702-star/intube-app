# INTUBE project (patched baseline)

## What was repaired in this package
- Single shared upload handler (`upload.js`) for the main app and upload page.
- Removed Cloudinary dependency from upload flow.
- Media files are stored in browser IndexedDB; post metadata is written to Firestore.
- Main feed now uses the same Firestore schema (`createdAt`, `uid/userId`, `mediaType/type`, `caption`) and listens with `onSnapshot`.
- Like toggles use Firestore array transforms; comments are written to per-post subcollections and rendered in realtime.
- `firebase.js` re-exports the single initialized Firebase app from `firebase-config.js`.
- Added input size/type checks and visible upload errors.

## IMPORTANT storage limitation
This temporary free mode stores photo/video bytes only on the uploader's device (IndexedDB). Firestore syncs metadata in realtime, but other users/devices cannot fetch that local media. It is NOT a publish-ready social-media storage design. To share media across users, enable Firebase Storage or another object storage later. Browser local storage/IndexedDB is also not reliable permanent storage and can be cleared by the user/browser.

## Before Play Store launch
- Configure Google sign-in in Firebase Authentication and set authorized domains.
- Review Firestore Security Rules (never leave public write access).
- Test using two separate accounts/devices, Android WebView, slow network, large files, and account logout.
- Implement/verify follow, direct messaging, notifications, story expiry/views, report/block, pagination, moderation, privacy policy, account deletion, and Play policy requirements. These features are not all fully implemented by this patch.
- Serve over HTTPS; do not open HTML via `file://`.

This package is a repaired development baseline, not a guarantee of zero bugs or Play Store readiness.
