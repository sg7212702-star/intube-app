// Backward-compatible Firebase entry point. Use one initialized app everywhere.
export { firebaseConfig, auth, db } from "./firebase-config.js";
