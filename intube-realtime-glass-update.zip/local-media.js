// Device-local media storage. Firestore stores only metadata; media is not synced to other devices.
const DB_NAME = "intube-local-media";
const STORE = "media";
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
export async function saveLocalMedia(file){const db=await openDB();const key=`${Date.now()}_${crypto.randomUUID?.()||Math.random().toString(36).slice(2)}`;await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(file,key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});db.close();return key}
export async function getLocalMediaURL(key){if(!key)return '';try{const db=await openDB();const blob=await new Promise((resolve,reject)=>{const r=db.transaction(STORE).objectStore(STORE).get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});db.close();return blob?URL.createObjectURL(blob):''}catch{return ''}}
export async function deleteLocalMedia(key){if(!key)return;const db=await openDB();await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});db.close()}
