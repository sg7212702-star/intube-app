import { auth, db } from './firebase-config.js';
import { collection, addDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js';

const $ = id => document.getElementById(id);
const status = $('status') || $('upStatus');
const say = message => { if (status) { status.textContent = message; status.style.display = 'block'; } else alert(message); };
const fileInput = $('fileInput') || $('mediaFile');
let uploadType = 'post';
$('optPost')?.addEventListener('click', () => { uploadType='post'; if(fileInput){fileInput.accept='image/*,video/*';fileInput.click();} });
$('optReel')?.addEventListener('click', () => { uploadType='reel'; if(fileInput){fileInput.accept='video/*';fileInput.click();} });

async function uploadSelectedFile(){
 const file=fileInput?.files?.[0]; if(!file){say('पहले फोटो या वीडियो चुनें।');return;}
 const user=auth.currentUser; if(!user){say('अपलोड करने से पहले लॉगिन करें।');return;}
 if(!file.type.startsWith('image/')&&!file.type.startsWith('video/')){say('केवल फोटो या वीडियो अपलोड करें।');return;}
 const max=file.type.startsWith('video/')?100*1024*1024:20*1024*1024;
 if(file.size>max){say(`फाइल बड़ी है। अधिकतम ${file.type.startsWith('video/')?'100 MB':'20 MB'} रखें।`);return;}
 const caption=$('caption')?.value?.trim()||''; const button=$('uploadBtn'); if(button)button.disabled=true;
 try{
  say('Cloud पर मीडिया अपलोड हो रहा है…');
  const storage=getStorage();
  const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
  const mediaRef=ref(storage,`user-media/${user.uid}/${Date.now()}-${safeName}`);
  const task=uploadBytesResumable(mediaRef,file,{contentType:file.type,customMetadata:{ownerUid:user.uid}});
  await new Promise((resolve,reject)=>{task.on('state_changed',s=>{const pct=Math.round(s.bytesTransferred/s.totalBytes*100);say(`अपलोड हो रहा है… ${pct}%`);},reject,resolve);});
  const mediaUrl=await getDownloadURL(task.snapshot.ref);
  const mediaType=file.type.startsWith('video/')?'video':'image';
  await addDoc(collection(db,'posts'),{uid:user.uid,userId:user.uid,username:user.displayName||user.email||'User',userName:user.displayName||user.email||'User',userPhoto:user.photoURL||'',userPic:user.photoURL||'',caption,mediaType,type:uploadType==='reel'?'reel':mediaType,mediaUrl,imageUrl:mediaUrl,url:mediaUrl,likes:[],likesCount:0,createdAt:serverTimestamp(),time:Date.now(),storageMode:'firebase-storage'});
  if($('caption'))$('caption').value='';fileInput.value='';say('सफलता! पोस्ट अब दूसरे यूजर्स को भी दिखाई दे सकती है।');
 }catch(error){console.error(error);say(`अपलोड असफल: ${error.message||'Firebase सेटिंग जाँचें'}`);}
 finally{if(button)button.disabled=false;}
}
fileInput?.addEventListener('change',()=>{if(fileInput.files?.length)uploadSelectedFile();});
$('uploadBtn')?.addEventListener('click',uploadSelectedFile);
